/**@IFPB
 * @author Alan Giovanni | Suelando Alves | William Soares
 * @version 1.0
 * @since 03 December 2017
 * @CommentLanguage Pt-Br
 * 
 * Esta cole��o representa um ARRAY de Usuarios que acessar�o o sistema de vendas
 */
package sistemaDeVendas.collections;
import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.Serializable;
import java.util.ArrayList;

import com.thoughtworks.xstream.XStream;
import com.thoughtworks.xstream.io.xml.StaxDriver;
import com.thoughtworks.xstream.security.AnyTypePermission;

import sistemaDeVendas.classes.Clientes;
import sistemaDeVendas.classes.Usuarios;

public class ColUsuarios implements Serializable{

	private ArrayList<Usuarios> colUsuarios = new ArrayList<Usuarios>();
	private static final long serialVersionUID = 1L;
	
	public ColUsuarios(){
		
	}
	
	public void adicionaUsuarioNaLista(Usuarios usuario){
		colUsuarios.add(usuario);
	}
	
	public void removeUsuarioDaLista(Usuarios usuario){
		colUsuarios.remove(usuario);
	}
	
	public boolean autenticacao(String login, String senha){
		for(Usuarios user: colUsuarios) {
			if(user.getLogin().equals(login) && user.getSenha().equals(senha)) {
				return true;
			}
		}
		return false;
	}
	@Override
	public String toString() {
		return "ColUsuarios [colUsuarios=" + colUsuarios + "]";
	}
	
	public void salvaEmXML(String localArmazenamento){
		XStream xStream = new XStream(new StaxDriver());
        File arquivo = new File(localArmazenamento);
        xStream.alias("Usuario", Usuarios.class);
        FileOutputStream gravar;
        try {
            gravar = new FileOutputStream(arquivo);
            gravar.write(xStream.toXML(colUsuarios).getBytes());
            gravar.close();
        } catch (IOException ex) {
            ex.printStackTrace();
        } 
		
	}
	
	public void lerDoXML(String localArmazenamento){
		try {
			XStream xStream = new XStream(new StaxDriver());
			//Quest�es de seguran�a
			XStream.setupDefaultSecurity(xStream);
			xStream.addPermission(AnyTypePermission.ANY); 
			xStream.alias("Usuario", Usuarios.class);
			xStream.processAnnotations(Usuarios.class);
			BufferedInputStream input = new BufferedInputStream(new FileInputStream(localArmazenamento));
			ArrayList<Usuarios> lista = (ArrayList<Usuarios>) xStream.fromXML(input);
			input.close();
			
			this.colUsuarios = lista;
			
		} catch (IOException ex) {
			ex.printStackTrace();
		}
	}
}