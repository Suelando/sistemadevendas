package sistemaDeVendas.view;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import sistemaDeVendas.classes.Usuarios;
import sistemaDeVendas.collections.ColUsuarios;
import sistemaDeVendas.collections.ColVendas;

import java.awt.Toolkit;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.ImageIcon;
import javax.swing.JTextField;
import java.awt.Font;
import javax.swing.SwingConstants;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.io.File;
import java.awt.event.ActionEvent;

public class ViewLogin extends JFrame {

	private JPanel contentPane;
	private JTextField textLogin;
	private JTextField textSenha;
	
	private ColUsuarios usuarios = new ColUsuarios();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ViewLogin frame = new ViewLogin();
					frame.setVisible(true);
					frame.setLocationRelativeTo(null);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public ViewLogin() {
		//BUSCAR OS LOGINS SALVOS ARMAZENADOS
		if(existeXML("armazenamento/ColUsuarios.xml")){
			usuarios.lerDoXML("armazenamento/ColUsuarios.xml");
		}
		
		setTitle("Tela de Login");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 705, 420);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblIconLogin = new JLabel("");
		lblIconLogin.setIcon(new ImageIcon("C:\\Users\\Alan\\workspace\\Projeto_Final_POO\\bin\\Images\\entrar.png"));
		lblIconLogin.setBounds(259, 23, 212, 200);
		contentPane.add(lblIconLogin);
		
		JLabel lblLogin = new JLabel("Usu\u00E1rio:");
		lblLogin.setHorizontalAlignment(SwingConstants.CENTER);
		lblLogin.setFont(new Font("Tahoma", Font.PLAIN, 13));
		lblLogin.setBounds(163, 237, 62, 27);
		contentPane.add(lblLogin);
		
		textLogin = new JTextField();
		textLogin.setHorizontalAlignment(SwingConstants.CENTER);
		textLogin.setBounds(235, 234, 262, 30);
		contentPane.add(textLogin);
		textLogin.setColumns(10);
		
		JLabel lblSenha = new JLabel("Senha:");
		lblSenha.setHorizontalAlignment(SwingConstants.CENTER);
		lblSenha.setFont(new Font("Tahoma", Font.PLAIN, 13));
		lblSenha.setBounds(163, 275, 62, 27);
		contentPane.add(lblSenha);
		
		textSenha = new JTextField();
		textSenha.setHorizontalAlignment(SwingConstants.CENTER);
		textSenha.setBounds(235, 275, 262, 30);
		contentPane.add(textSenha);
		textSenha.setColumns(10);
		
		JButton btnEntrar = new JButton("Entrar");
		btnEntrar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String login = textLogin.getText();
				String senha = textSenha.getText();
				
				//TESTA SE OS CAMPOS EST�O EM BRANCOS
				if(login.isEmpty() || senha.isEmpty()){
					JOptionPane.showMessageDialog (null, "PREENCHA OS DOIS CAMPOS","CAMPO EM BRANCO", JOptionPane.ERROR_MESSAGE);
					textLogin.setText("");
					textSenha.setText("");
					
					//SE N�O TIVER VEM PRA C�
				} else {
					//VERIFICA SE O USU�RIO EST� CADASTRADO OU DIGITOU CORRETAMENTE SUAS CREDENCIAS
					boolean autenticado = usuarios.autenticacao(login, senha);
				
					if(autenticado){
						//CASO LOGIN E SENHA ESTEJAM CORRETOS
						
						//USUARIO AUTENTICADO - PASSA O NOME PRA VIEW PRINCIPAL
						viewPrincipal obj = new viewPrincipal(autenticado, login);
						obj.setLocationRelativeTo(null);
						obj.setVisible(true);
						dispose();
					} else{
						JOptionPane.showMessageDialog (null, "CREDENCIAIS ERRADAS OU USUARIO N�O CADASTRADO","ERRO AO AUTENTICAR", JOptionPane.ERROR_MESSAGE);
						textLogin.setText("");
						textSenha.setText("");
					}
				}
			}
		});
		btnEntrar.setFont(new Font("Tahoma", Font.PLAIN, 14));
		btnEntrar.setBounds(235, 316, 125, 38);
		contentPane.add(btnEntrar);
		
		JButton btnCadastrar = new JButton("Criar Conta");
		btnCadastrar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String login = textLogin.getText();
				String senha = textSenha.getText();
				
				if(login.isEmpty() || senha.isEmpty()){
					JOptionPane.showMessageDialog (null, "PREENCHA OS DOIS CAMPOS","CAMPO EM BRANCO", JOptionPane.ERROR_MESSAGE);
					textLogin.setText("");
					textSenha.setText("");
				} else {
					Usuarios novoUsuario = new Usuarios(login, senha);
					usuarios.adicionaUsuarioNaLista(novoUsuario);
					usuarios.salvaEmXML("armazenamento/ColUsuarios.xml");
					JOptionPane.showMessageDialog (null, "Usu�rio cadastrado com SUCESSO!");
				}
			}
		});
		btnCadastrar.setFont(new Font("Tahoma", Font.PLAIN, 13));
		btnCadastrar.setBounds(393, 316, 104, 38);
		contentPane.add(btnCadastrar);
		
		JLabel lblFundo = new JLabel("New label");
		lblFundo.setHorizontalAlignment(SwingConstants.CENTER);
		lblFundo.setIcon(new ImageIcon("C:\\Users\\Alan\\workspace\\Projeto_Final_POO\\bin\\Images\\FundoLogin.jpg"));
		lblFundo.setBounds(0, 0, 689, 381);
		contentPane.add(lblFundo);
	}
	private boolean existeXML(String caminhoDoArquivo){
		File arquivo = new File(caminhoDoArquivo);
		if(arquivo.exists()){
		return true;
		} else{
			return false;
		}
	}
}
